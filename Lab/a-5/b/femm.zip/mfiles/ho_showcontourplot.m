% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_showcontourplot(numcontours,al,au)
callfemm(['ho_showcontourplot(' , numc(numcontours) , numc(al) , num(au) , ')' ]);

