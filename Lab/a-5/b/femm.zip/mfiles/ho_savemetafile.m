% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_savemetafile(fn)
callfemm(['ho_savemetafile(' , quote(fn) , ')' ]);

