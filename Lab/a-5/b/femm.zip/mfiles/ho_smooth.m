% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_smooth(flag)
callfemm(['ho_smooth(' , quote(flag) , ')' ]);

