% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_deleteconductor(n)
callfemm(['ei_deleteconductor(' , quote(n) , ')' ]);

