% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_hidegrid()
callfemm('co_hidegrid()');

