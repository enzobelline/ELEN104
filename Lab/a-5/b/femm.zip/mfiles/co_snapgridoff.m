% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_snapgridoff()
callfemm('co_gridsnap("off")');

