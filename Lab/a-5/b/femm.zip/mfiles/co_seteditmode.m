% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_seteditmode(mode)
callfemm(['co_seteditmode(' , quote(mode) , ')' ]);

