% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_savebitmap(fn)
callfemm(['eo_savebitmap(' , quote(fn) , ')' ]);

