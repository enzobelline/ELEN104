% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_smartmesh(n)
callfemm(['ci_smartmesh(' , num(n), ')' ]);

