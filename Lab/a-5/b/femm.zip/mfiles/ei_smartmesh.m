% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_smartmesh(n)
callfemm(['ei_smartmesh(' , num(n), ')' ]);

