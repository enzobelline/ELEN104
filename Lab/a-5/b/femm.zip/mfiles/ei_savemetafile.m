% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_savemetafile(n)
callfemm(['ei_savemetafile(' , quote(n) , ')' ]);

