% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_showdensityplot(legend,gscale,ptype,bu,bl)
callfemm(['co_showdensityplot(' , numc(legend) , numc(gscale) , numc(ptype) , numc(bu) , num(bl) , ')' ]);

