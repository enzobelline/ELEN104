% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_zoomin()
callfemm('ci_zoomin()');

