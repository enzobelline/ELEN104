% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_snapgrid(flag)
callfemm(['co_gridsnap(' , quote(flag) , ')' ]);

