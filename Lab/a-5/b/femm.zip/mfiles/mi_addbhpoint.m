% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function mi_addbhpoint(name,b,h)
callfemm(['mi_addbhpoint(' , quotec(name) , numc(b) , num(h) , ')' ]);

