% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=ei_setgroup(n)
z=callfemm(['ei_setgroup(' , num(n) , ')' ]);

