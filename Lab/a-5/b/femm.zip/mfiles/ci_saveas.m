% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_saveas(fn)
callfemm(['ci_saveas(' , quote(fn) , ')']);

