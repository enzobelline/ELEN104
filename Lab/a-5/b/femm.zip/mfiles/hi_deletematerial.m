% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_deletematerial(n)
callfemm(['hi_deletematerial(' , quote(n) , ')' ]);

