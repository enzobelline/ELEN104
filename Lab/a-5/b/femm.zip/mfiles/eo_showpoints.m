% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_showpoints()
callfemm('eo_showpoints()');

