% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_zoomnatural()
callfemm('hi_zoomnatural()');

