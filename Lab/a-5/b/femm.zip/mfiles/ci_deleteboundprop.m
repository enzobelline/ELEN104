% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_deleteboundprop(n)
callfemm(['ci_deleteboundprop(' , quote(n) , ')' ]);

