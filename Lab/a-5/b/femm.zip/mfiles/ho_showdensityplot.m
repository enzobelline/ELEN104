% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_showdensityplot(legend,gscale,ptype,bu,bl)
callfemm(['ho_showdensityplot(' , numc(legend) , numc(gscale) , numc(ptype) , numc(bu) , num(bl) , ')' ]);

