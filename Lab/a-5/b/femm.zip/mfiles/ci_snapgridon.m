% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_snapgridon()
callfemm('ci_gridsnap("on")');

