% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_addtkpoint(name,b,h)
callfemm(['hi_addtkpoint(' , quotec(name) , numc(b) , num(h) , ')' ]);

