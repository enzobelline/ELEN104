% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_zoomout()
callfemm('ei_zoomout()');

