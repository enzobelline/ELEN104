% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_smoothon()
callfemm('eo_smooth("on")');

