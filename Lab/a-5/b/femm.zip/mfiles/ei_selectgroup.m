% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_selectgroup(gr)
callfemm(['ei_selectgroup(' , num(gr) , ')' ]);

