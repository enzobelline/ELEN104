% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_deleteselectedsegments()
callfemm('ci_deleteselectedsegments()');

