% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function mi_createradius(x,y,r)
callfemm(['mi_createradius(' , numc(x) , numc(y), num(r) , ')' ]);


