% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_showcontourplot(numcontours,al,au)
callfemm(['co_showcontourplot(' , numc(numcontours) , numc(al) , num(au) , ')' ]);

