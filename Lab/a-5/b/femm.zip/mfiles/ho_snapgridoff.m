% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_snapgridoff()
callfemm('ho_gridsnap("off")');

