% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function main_minimize()
	callfemm('main_minimize()');

