% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_snapgridoff()
callfemm('ci_gridsnap("off")');

