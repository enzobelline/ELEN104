% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_hidedensityplot()
callfemm('co_hidedensityplot()');

