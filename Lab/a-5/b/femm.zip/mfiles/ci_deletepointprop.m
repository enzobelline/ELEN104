% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_deletepointprop(n)
callfemm(['ci_deletepointprop(' , quote(n) , ')' ]);

