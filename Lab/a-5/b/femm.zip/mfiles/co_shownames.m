% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_shownames()
callfemm('co_shownames(1)');

