% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_hidegrid()
callfemm('ho_hidegrid()');

