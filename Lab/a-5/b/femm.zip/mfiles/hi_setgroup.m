% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=hi_setgroup(n)
z=callfemm(['hi_setgroup(' , num(n) , ')' ]);

