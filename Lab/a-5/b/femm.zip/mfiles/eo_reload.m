% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_reload()
callfemm('eo_reload()');

