% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function dia=AWG(awg)
dia=8.2514694*exp(-0.115943*awg);

