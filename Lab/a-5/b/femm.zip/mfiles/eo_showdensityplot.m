% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_showdensityplot(legend,gscale,ptype,bu,bl)
callfemm(['eo_showdensityplot(' , numc(legend) , numc(gscale) , numc(ptype) , numc(bu) , num(bl) , ')' ]);

