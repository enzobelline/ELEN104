% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=ei_createmesh()
z=callfemm('ei_createmesh()');

