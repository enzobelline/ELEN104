% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_deleteboundprop(n)
callfemm(['ei_deleteboundprop(' , quote(n) , ')' ]);

