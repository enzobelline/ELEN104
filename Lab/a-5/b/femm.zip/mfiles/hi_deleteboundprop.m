% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_deleteboundprop(n)
callfemm(['hi_deleteboundprop(' , quote(n) , ')' ]);

