% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_zoomnatural()
callfemm('ei_zoomnatural()');

