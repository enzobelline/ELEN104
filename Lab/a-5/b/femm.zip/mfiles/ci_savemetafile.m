% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_savemetafile(n)
callfemm(['ci_savemetafile(' , quote(n) , ')' ]);

