% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_cleartkpoints(n)
callfemm(['ci_cleartkpoints(' , quote(n) , ')' ]);

