% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=ci_setgroup(n)
z=callfemm(['ci_setgroup(' , num(n) , ')' ]);



