% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=co_numnodes()
z=callfemm('co_numnodes()');

