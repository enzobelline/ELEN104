% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_restore()
	callfemm('co_restore()');

