% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function eo_smooth(flag)
callfemm(['eo_smooth(' , quote(flag) , ')' ]);

