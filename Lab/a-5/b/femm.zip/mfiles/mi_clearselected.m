% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function mi_clearselected()
callfemm(['mi_clearselected()']);

