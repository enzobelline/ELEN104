% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_close()
callfemm('ho_close()');

