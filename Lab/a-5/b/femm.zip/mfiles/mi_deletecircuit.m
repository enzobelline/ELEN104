% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function mi_deletecircuit(n)
callfemm(['mi_deletecircuit(' , quote(n) , ')' ]);

