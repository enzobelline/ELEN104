% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_maximize()
	callfemm('ci_maximize()');

