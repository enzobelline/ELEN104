% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_readdxf(docname)
callfemm(['print(ci_readdxf(' , quote(docname) , '))' ]);

