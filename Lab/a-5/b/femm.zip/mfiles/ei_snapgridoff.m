% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_snapgridoff()
callfemm('ei_gridsnap("off")');

