% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ei_savebitmap(n)
callfemm(['ei_savebitmap(' , quote(n) , ')' ]);

