% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_deleteselectedsegments()
callfemm('hi_deleteselectedsegments()');

