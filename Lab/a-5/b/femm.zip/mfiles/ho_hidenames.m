% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ho_hidenames()
callfemm('ho_shownames(0)');

