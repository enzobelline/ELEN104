% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=ci_createmesh()
z=callfemm('ci_createmesh()');

