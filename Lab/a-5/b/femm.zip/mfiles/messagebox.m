% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function messagebox(msg)
callfemm(['messagebox(' , quote(msg) , ')' ]);

