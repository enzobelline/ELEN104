% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function z=mi_createmesh()
z=callfemm('mi_createmesh()');

