% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_saveas(fn)
callfemm(['hi_saveas(' , quote(fn) , ')']);

