% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function co_smoothoff()
callfemm('co_smooth("off")');

