% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function ci_setfocus(docname)
callfemm(['ci_setfocus(' , quote(docname) , ')' ]);

