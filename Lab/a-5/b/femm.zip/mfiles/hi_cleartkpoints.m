% ActiveFEMM (C)2006 David Meeker, dmeeker@ieee.org

function hi_cleartkpoints(n)
callfemm(['hi_cleartkpoints(' , quote(n) , ')' ]);


